import java.nio.file.*;
import com.telamin.mongoose.control.ControlAuditExport;
import com.telamin.mongoose.control.validation.*;
class VerifyAudit {
 public static void main(String[] args) throws Exception {
  for (String name:args) {
   Path file=Path.of(name);
   var integrity=ControlAuditExport.verify(file);
   var evidence=ControlEvidence.parse(Files.readString(file),integrity.permitsInvariantPass());
   var result=ControlInvariants.check(evidence);
   System.out.println(file.getFileName()+" "+integrity+" records="+evidence.records().size()+" verified="+result.verified()+" "+result);
   if(!integrity.permitsInvariantPass() || !result.verified()) throw new AssertionError(name);
  }
 }
}